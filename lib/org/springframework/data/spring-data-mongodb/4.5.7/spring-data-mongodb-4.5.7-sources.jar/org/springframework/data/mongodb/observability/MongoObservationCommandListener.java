/*
 * Copyright 2022-2025 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.data.mongodb.observability;

import io.micrometer.observation.Observation;
import io.micrometer.observation.ObservationRegistry;
import io.micrometer.observation.ObservationView;
import io.micrometer.observation.contextpropagation.ObservationThreadLocalAccessor;

import java.util.function.BiConsumer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.lang.Nullable;
import org.springframework.util.Assert;

import com.mongodb.ConnectionString;
import com.mongodb.RequestContext;
import com.mongodb.event.CommandFailedEvent;
import com.mongodb.event.CommandListener;
import com.mongodb.event.CommandStartedEvent;
import com.mongodb.event.CommandSucceededEvent;

/**
 * Implement MongoDB's {@link CommandListener} using Micrometer's {@link Observation} API.
 *
 * @author OpenZipkin Brave Authors
 * @author Marcin Grzejszczak
 * @author Greg Turnquist
 * @author François Kha
 * @since 4.0
 */
public class MongoObservationCommandListener implements CommandListener {

	private static final Log log = LogFactory.getLog(MongoObservationCommandListener.class);

	private final ObservationRegistry observationRegistry;
	private final @Nullable ConnectionString connectionString;

	private final MongoHandlerObservationConvention observationConvention;

	/**
	 * Create a new {@link MongoObservationCommandListener} to record {@link Observation}s.
	 *
	 * @param observationRegistry must not be {@literal null}
	 */
	public MongoObservationCommandListener(ObservationRegistry observationRegistry) {
		this(observationRegistry, null);
	}

	/**
	 * Create a new {@link MongoObservationCommandListener} to record {@link Observation}s. This constructor attaches the
	 * {@link ConnectionString} to every {@link Observation}.
	 *
	 * @param observationRegistry must not be {@literal null}
	 * @param connectionString can be {@literal null}
	 */
	public MongoObservationCommandListener(ObservationRegistry observationRegistry,
			@Nullable ConnectionString connectionString) {
		this(observationRegistry, connectionString, new DefaultMongoHandlerObservationConvention());
	}

	/**
	 * Create a new {@link MongoObservationCommandListener} to record {@link Observation}s. This constructor attaches the
	 * {@link ConnectionString} to every {@link Observation} and uses the given {@link MongoHandlerObservationConvention}.
	 *
	 * @param observationRegistry must not be {@literal null}
	 * @param connectionString can be {@literal null}
	 * @param observationConvention must not be {@literal null}
	 * @since 4.3
	 */
	public MongoObservationCommandListener(ObservationRegistry observationRegistry,
			@Nullable ConnectionString connectionString, MongoHandlerObservationConvention observationConvention) {

		Assert.notNull(observationRegistry, "ObservationRegistry must not be null");
		Assert.notNull(observationConvention, "ObservationConvention must not be null");

		this.observationRegistry = observationRegistry;
		this.connectionString = connectionString;
		this.observationConvention = observationConvention;
	}

	@Override
	public void commandStarted(CommandStartedEvent event) {

		if (log.isDebugEnabled()) {
			log.debug("Instrumenting the command started event");
		}

		String databaseName = event.getDatabaseName();

		if ("admin".equals(databaseName)) {
			return; // don't instrument commands like "endSessions"
		}

		RequestContext requestContext = event.getRequestContext();

		if (requestContext == null) {
			return;
		}

		Observation parent = observationFromContext(requestContext);

		MongoHandlerContext observationContext = new MongoHandlerContext(connectionString, event, requestContext);
		observationContext.setRemoteServiceName("mongo");

		Observation observation = MongoObservation.MONGODB_COMMAND_OBSERVATION
				.observation(this.observationRegistry, () -> observationContext) //
				.observationConvention(this.observationConvention);

		if (parent != null) {
			observation.parentObservation(parent);
		}

		observation.start();

		requestContext.put(ObservationThreadLocalAccessor.KEY, observation);

		if (log.isDebugEnabled()) {
			log.debug(
					"Created a child observation  [" + observation + "] for Mongo instrumentation and put it in Mongo context");
		}
	}

	@Override
	public void commandSucceeded(CommandSucceededEvent event) {

		stopObservation(event.getRequestContext(), (observation, context) -> {

			context.setCommandSucceededEvent(event);

			if (log.isDebugEnabled()) {
				log.debug("Command succeeded - will stop observation [" + observation + "]");
			}
		});
	}

	@Override
	public void commandFailed(CommandFailedEvent event) {

		stopObservation(event.getRequestContext(), (observation, context) -> {

			context.setCommandFailedEvent(event);

			if (log.isDebugEnabled()) {
				log.debug("Command failed - will stop observation [" + observation + "]");
			}

			observation.error(event.getThrowable());
		});
	}

	/**
	 * Stops the {@link Observation} after applying {@code action} given {@link MongoHandlerContext} if there is an
	 * ongoing Mongo Observation. Exceptions thrown by the action are relayed to the caller.
	 *
	 * @param requestContext the context to extract the Observation from.
	 * @param action the action to invoke.
	 */
	private void stopObservation(@Nullable RequestContext requestContext,
			BiConsumer<Observation, MongoHandlerContext> action) {

		if (requestContext == null) {
			return;
		}

		Observation observation = requestContext.getOrDefault(ObservationThreadLocalAccessor.KEY, null);
		if (observation == null || !(observation.getContext() instanceof MongoHandlerContext context)) {
			return;
		}

		try {
			action.accept(observation, context);
		} finally {

			observation.stop();

			if (log.isDebugEnabled()) {
				log.debug(
						"Restoring parent observation [" + observation + "] for Mongo instrumentation and put it in Mongo context");
			}
			ObservationView parentObservation = observation.getContext().getParentObservation();

			if (parentObservation == null) {
				requestContext.delete(ObservationThreadLocalAccessor.KEY);
			} else {
				requestContext.put(ObservationThreadLocalAccessor.KEY, parentObservation);
			}
		}
	}

	/**
	 * Extract the {@link Observation} from MongoDB's {@link RequestContext}.
	 *
	 * @param context
	 * @return
	 */
	@Nullable
	private static Observation observationFromContext(RequestContext context) {

		Observation observation = context.getOrDefault(ObservationThreadLocalAccessor.KEY, null);

		if (observation != null) {

			if (log.isDebugEnabled()) {
				log.debug("Found a observation in Mongo context [" + observation + "]");
			}
			return observation;
		}

		if (log.isDebugEnabled()) {
			log.debug("No observation was found: Creating a new root observation");
		}

		return null;
	}
}
